import os

os.environ["AI_ENABLED"] = "false"
os.environ["DATABASE_URL"] = "sqlite:///./data/test_fitbuddy.db"
os.environ["ADMIN_TOKEN"] = "test-token"

from fastapi.testclient import TestClient

from app.main import app
from app.database import init_db

init_db()
client = TestClient(app)


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "FitBuddy" in response.text


def test_generate_workout_demo_mode():
    response = client.post(
        "/api/generate-workout",
        json={
            "user_id": "TEST001",
            "name": "Test User",
            "age": 21,
            "weight": 60,
            "goal": "general wellness",
            "intensity": "medium",
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert len(body["workout_plan"]["days"]) == 7
    assert "tip" in body["nutrition_tip"]


def test_feedback_demo_mode():
    response = client.post(
        "/api/submit-feedback",
        json={"user_id": "TEST001", "feedback": "Please include more cardio and a rest day."},
    )
    assert response.status_code == 200
    assert len(response.json()["updated_plan"]["days"]) == 7


def test_admin_requires_token():
    assert client.get("/api/users").status_code == 401
    response = client.get("/api/users", headers={"x-admin-token": "test-token"})
    assert response.status_code == 200
    assert isinstance(response.json(), list)
