from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "FitBuddy"
    debug: bool = True
    database_url: str = "sqlite:///./data/fitbuddy.db"
    gemini_api_key: str | None = None
    gemini_plan_model: str = "gemini-3.8-flash"
    gemini_tip_model: str = "gemini-3.8-flash"
    ai_enabled: bool = True
    admin_token: str = "change-me"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @property
    def gemini_ready(self) -> bool:
        return self.ai_enabled and bool(self.gemini_api_key)


@lru_cache
def get_settings() -> Settings:
    return Settings()
