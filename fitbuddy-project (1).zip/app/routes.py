import json
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Header, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .config import get_settings
from .database import delete_user, get_all_users, get_db, get_user, save_plan, save_user, update_plan
from .schemas import FeedbackRequest, UserInput, WorkoutPlan
from .services.gemini_flash_generator import generate_nutrition_tip_with_flash
from .services.gemini_generator import generate_workout_gemini
from .services.updated_plan import update_workout_plan

router = APIRouter()
settings = get_settings()
templates = Jinja2Templates(directory="templates")


def _plan_dict(plan_text: str) -> dict:
    try:
        return WorkoutPlan.model_validate_json(plan_text).model_dump()
    except Exception:
        try:
            return json.loads(plan_text)
        except Exception:
            return {"overview": plan_text, "safety_note": "Review the generated text carefully.", "days": []}


def _user_context(user, plan_text: str | None = None):
    current_plan = plan_text or user.updated_plan or user.original_plan
    return {
        "user": user,
        "plan": _plan_dict(current_plan),
        "original_plan": _plan_dict(user.original_plan) if user.original_plan else None,
        "nutrition_tip": _plan_dict_tip(user.nutrition_tip),
    }


def _plan_dict_tip(tip_text: str) -> dict:
    try:
        return json.loads(tip_text)
    except Exception:
        return {"tip": tip_text, "recovery_note": ""}


def _check_admin(token: str | None) -> None:
    if not token or token != settings.admin_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid admin token")




@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"settings": settings})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout_form(
    request: Request,
    user_id: Annotated[str, Form()],
    name: Annotated[str, Form()],
    age: Annotated[int, Form()],
    weight: Annotated[float, Form()],
    goal: Annotated[str, Form()],
    intensity: Annotated[str, Form()],
    db: Session = Depends(get_db),
):
    try:
        user_input = UserInput(user_id=user_id, name=name, age=age, weight=weight, goal=goal, intensity=intensity)
        user = save_user(db, **user_input.model_dump())
        plan = generate_workout_gemini(user_input)
        tip = generate_nutrition_tip_with_flash(user_input)
        save_plan(db, user, plan, tip)
        user = get_user(db, user_input.user_id)
        return templates.TemplateResponse(request=request, name="result.html", context=_user_context(user))
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"settings": settings, "error": str(exc), "form": locals()},
            status_code=400,
        )


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback_form(
    request: Request,
    user_id: Annotated[str, Form()],
    feedback: Annotated[str, Form()],
    db: Session = Depends(get_db),
):
    try:
        payload = FeedbackRequest(user_id=user_id, feedback=feedback)
        user = get_user(db, payload.user_id)
        if not user or not user.original_plan:
            raise ValueError("User ID not found or no original plan exists.")
        updated = update_workout_plan(user.original_plan, payload.feedback)
        update_plan(db, user, updated, payload.feedback)
        user = get_user(db, payload.user_id)
        return templates.TemplateResponse(request=request, name="result.html", context=_user_context(user))
    except Exception as exc:
        user = get_user(db, user_id.strip()) if user_id else None
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={**(_user_context(user) if user else {"user": None, "plan": None, "nutrition_tip": {}}), "error": str(exc)},
            status_code=400,
        )


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, token: str | None = None, db: Session = Depends(get_db)):
    try:
        _check_admin(token)
    except HTTPException as exc:
        return templates.TemplateResponse(request=request, name="admin_login.html", context={"error": exc.detail}, status_code=401)
    users = get_all_users(db)
    return templates.TemplateResponse(request=request, name="all_users.html", context={"users": users, "token": token})


@router.post("/admin/delete/{user_id}")
def delete_user_form(user_id: str, token: Annotated[str, Form()], db: Session = Depends(get_db)):
    _check_admin(token)
    delete_user(db, user_id)
    return RedirectResponse(url=f"/view-all-users?token={token}", status_code=303)


@router.post("/api/generate-workout")
def api_generate(payload: UserInput, db: Session = Depends(get_db)):
    user = save_user(db, **payload.model_dump())
    plan = generate_workout_gemini(payload)
    tip = generate_nutrition_tip_with_flash(payload)
    save_plan(db, user, plan, tip)
    return {"user_id": payload.user_id, "workout_plan": _plan_dict(plan), "nutrition_tip": _plan_dict_tip(tip)}


@router.post("/api/submit-feedback")
def api_feedback(payload: FeedbackRequest, db: Session = Depends(get_db)):
    user = get_user(db, payload.user_id)
    if not user or not user.original_plan:
        raise HTTPException(status_code=404, detail="User ID not found or no plan exists")
    updated = update_workout_plan(user.original_plan, payload.feedback)
    update_plan(db, user, updated, payload.feedback)
    return {"user_id": payload.user_id, "updated_plan": _plan_dict(updated), "feedback": payload.feedback}


@router.get("/api/users")
def api_users(x_admin_token: Annotated[str | None, Header()] = None, db: Session = Depends(get_db)):
    _check_admin(x_admin_token)
    return [
        {
            "user_id": u.user_id,
            "name": u.name,
            "age": u.age,
            "weight": u.weight,
            "goal": u.goal,
            "intensity": u.intensity,
            "created_at": u.created_at,
            "updated_at": u.updated_at,
            "has_updated_plan": bool(u.updated_plan),
        }
        for u in get_all_users(db)
    ]
