from typing import Literal
from pydantic import BaseModel, Field, field_validator

Goal = Literal["weight loss", "muscle gain", "general wellness", "flexibility"]
Intensity = Literal["low", "medium", "high"]


class UserInput(BaseModel):
    user_id: str = Field(min_length=2, max_length=64)
    name: str = Field(min_length=2, max_length=100)
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, le=400)
    goal: Goal
    intensity: Intensity

    @field_validator("user_id", "name")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("This field cannot be blank")
        return value


class FeedbackRequest(BaseModel):
    user_id: str = Field(min_length=2, max_length=64)
    feedback: str = Field(min_length=5, max_length=1000)


class Exercise(BaseModel):
    name: str
    sets: int = Field(ge=1, le=10)
    reps_or_duration: str
    rest: str


class DayPlan(BaseModel):
    day: str
    focus: str
    warm_up: str
    exercises: list[Exercise]
    cool_down: str


class WorkoutPlan(BaseModel):
    overview: str
    safety_note: str
    days: list[DayPlan] = Field(min_length=7, max_length=7)


class NutritionTip(BaseModel):
    tip: str
    recovery_note: str
