from ..config import get_settings
from ..schemas import Exercise, WorkoutPlan

settings = get_settings()


def update_workout_plan(original_plan: str, feedback: str) -> str:
    if not settings.gemini_ready:
        return _fallback_update(original_plan, feedback)

    prompt = f"""
You are updating an existing 7-day fitness plan.

Original plan:
{original_plan}

User feedback:
{feedback}

Apply the feedback where reasonable while preserving the 7-day structure. Do not introduce dangerous exercise, medical treatment, extreme calorie restriction, or unsupported health claims. Keep a safety note.
"""
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=settings.gemini_api_key)
    response = client.models.generate_content(
        model=settings.gemini_plan_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=WorkoutPlan,
            temperature=0.6,
            max_output_tokens=5000,
        ),
    )
    if getattr(response, "parsed", None):
        return response.parsed.model_dump_json(indent=2) if hasattr(response.parsed, "model_dump_json") else str(response.parsed)
    return WorkoutPlan.model_validate_json(response.text).model_dump_json(indent=2)


def _fallback_update(original_plan: str, feedback: str) -> str:
    import json

    plan = WorkoutPlan.model_validate_json(original_plan)
    feedback_lower = feedback.lower()
    if "rest" in feedback_lower or "recovery" in feedback_lower:
        plan.days[3].focus = "Active recovery / rest"
        plan.days[3].exercises = [Exercise(name="Easy walk", sets=1, reps_or_duration="15–20 minutes", rest="As needed")]
    if "cardio" in feedback_lower:
        plan.days[6].focus = "Cardio + mobility"
        plan.days[6].exercises.insert(0, Exercise(name="Brisk walk or cycling", sets=1, reps_or_duration="20–30 minutes", rest="As needed"))
    if "yoga" in feedback_lower:
        plan.days[3].focus = "Gentle yoga / recovery"
        plan.days[3].exercises = [Exercise(name="Gentle yoga flow", sets=1, reps_or_duration="20 minutes", rest="As needed")]
    return plan.model_dump_json(indent=2)
