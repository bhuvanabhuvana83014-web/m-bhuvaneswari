from ..config import get_settings
from ..schemas import UserInput, WorkoutPlan

settings = get_settings()


def _client():
    from google import genai
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    return genai.Client(api_key=settings.gemini_api_key)


def _fallback_plan(user: UserInput) -> str:
    # Demo-mode plan: deterministic and intentionally conservative.
    focus_by_goal = {
        "weight loss": ["Full body + cardio", "Lower body + brisk walk", "Upper body + cardio", "Active recovery", "Full body circuit", "Cardio + core", "Mobility + light cardio"],
        "muscle gain": ["Upper body", "Lower body", "Push + core", "Active recovery", "Pull + core", "Lower body + conditioning", "Full body"],
        "general wellness": ["Full body", "Mobility + cardio", "Upper body", "Active recovery", "Lower body", "Full body", "Stretch + walk"],
        "flexibility": ["Full-body mobility", "Hips + hamstrings", "Shoulders + spine", "Gentle yoga", "Lower-body mobility", "Upper-body mobility", "Full-body flow"],
    }
    focuses = focus_by_goal[user.goal]
    days = []
    for i, focus in enumerate(focuses, start=1):
        rest = "30–60 sec" if user.intensity == "high" else "45–90 sec"
        days.append({
            "day": f"Day {i}",
            "focus": focus,
            "warm_up": "5–10 minutes of easy walking and dynamic mobility.",
            "exercises": [
                {"name": "Bodyweight squat", "sets": 3, "reps_or_duration": "10–12 reps", "rest": rest},
                {"name": "Incline push-up", "sets": 3, "reps_or_duration": "8–12 reps", "rest": rest},
                {"name": "Brisk walk", "sets": 1, "reps_or_duration": "15–25 minutes", "rest": "As needed"},
            ],
            "cool_down": "5 minutes of easy movement and comfortable stretching.",
        })
    return WorkoutPlan(
        overview=f"A {user.intensity}-intensity 7-day starter plan for {user.goal}, designed around consistency and gradual progression.",
        safety_note="Stop if you feel sharp pain, dizziness, chest pain, or unusual shortness of breath. Adjust exercises to your ability and consult a qualified professional for individualized medical advice.",
        days=days,
    ).model_dump_json(indent=2)


def generate_workout_gemini(user: UserInput) -> str:
    if not settings.gemini_ready:
        return _fallback_plan(user)

    prompt = f"""
Create a personalized 7-day fitness plan for this user:
Name: {user.name}
Age: {user.age}
Weight: {user.weight} kg
Goal: {user.goal}
Preferred intensity: {user.intensity}

Requirements:
- Return exactly 7 days.
- Each day must contain a focus, 5–10 minute warm-up, 2–4 exercises with sets/reps or duration and rest, and a cool-down/recovery instruction.
- Adapt difficulty to the requested intensity and goal.
- Include at least one recovery/light day where appropriate.
- Do not prescribe medication, diagnose illness, or give dangerous extreme exercise or dieting instructions.
- Keep the plan practical for a general adult beginner/intermediate user.
- Include a short overview and a safety note.
"""
    from google.genai import types
    client = _client()
    response = client.models.generate_content(
        model=settings.gemini_plan_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=WorkoutPlan,
            temperature=0.6,
            max_output_tokens=5000,
        ),
    )
    if getattr(response, "parsed", None):
        return response.parsed.model_dump_json(indent=2) if hasattr(response.parsed, "model_dump_json") else str(response.parsed)
    return WorkoutPlan.model_validate_json(response.text).model_dump_json(indent=2)
