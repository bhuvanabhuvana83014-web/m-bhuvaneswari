from ..config import get_settings
from ..schemas import NutritionTip, UserInput

settings = get_settings()


def _client():
    from google import genai
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_nutrition_tip_with_flash(user: UserInput) -> str:
    if not settings.gemini_ready:
        return _fallback_tip(user)

    prompt = f"""
Give one concise nutrition/recovery tip for a fitness user.
Goal: {user.goal}
Intensity: {user.intensity}
Age: {user.age}
Weight: {user.weight} kg

Avoid calorie prescriptions, medical claims, supplements, or extreme diets. Keep it practical and safe.
"""
    from google.genai import types
    client = _client()
    response = client.models.generate_content(
        model=settings.gemini_tip_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=NutritionTip,
            temperature=0.4,
            max_output_tokens=700,
        ),
    )
    if getattr(response, "parsed", None):
        return response.parsed.model_dump_json(indent=2) if hasattr(response.parsed, "model_dump_json") else str(response.parsed)
    return NutritionTip.model_validate_json(response.text).model_dump_json(indent=2)


def _fallback_tip(user: UserInput) -> str:
    tips = {
        "weight loss": ("Build meals around protein, vegetables, whole grains, and minimally processed foods.", "Prioritize regular sleep and hydration alongside training."),
        "muscle gain": ("Include a protein-rich food in each main meal, such as eggs, fish, beans, dairy, or lean meat.", "Allow recovery days and adequate sleep so your body can adapt to training."),
        "general wellness": ("Aim for balanced meals with protein, colorful produce, whole grains, and healthy fats.", "Hydrate regularly and keep a consistent sleep routine."),
        "flexibility": ("Stay hydrated and include protein and a variety of fruits and vegetables in your meals.", "Use gentle mobility work and avoid forcing a stretch into pain."),
    }
    tip, recovery = tips[user.goal]
    return NutritionTip(tip=tip, recovery_note=recovery).model_dump_json(indent=2)
