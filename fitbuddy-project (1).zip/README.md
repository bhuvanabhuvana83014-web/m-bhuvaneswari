# FitBuddy – AI Fitness Plan Generator

FitBuddy is a FastAPI + SQLite + Jinja2 web application based on the supplied project document. It generates a personalized 7-day workout plan, a nutrition/recovery tip, and an AI-updated plan from user feedback. It also includes an admin dashboard and JSON API endpoints.

## What is included

- FastAPI backend and interactive `/docs` API documentation
- Jinja2 HTML frontend
- SQLAlchemy + SQLite persistence
- Gemini integration using the current `google-genai` SDK
- Structured JSON output validated with Pydantic
- Workout generation
- Nutrition/recovery tip generation
- Feedback-based plan regeneration
- Admin dashboard with token protection and delete action
- Demo fallback mode when no Gemini key is configured
- Automated tests

## Architecture

```text
fitbuddy/
├── app/
│   ├── main.py
│   ├── routes.py
│   ├── config.py
│   ├── database.py
│   ├── schemas.py
│   └── services/
│       ├── gemini_generator.py
│       ├── gemini_flash_generator.py
│       └── updated_plan.py
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── result.html
│   ├── admin_login.html
│   └── all_users.html
├── static/css/style.css
├── tests/test_app.py
├── data/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. VS Code setup

1. Install Python 3.11+.
2. Open the `fitbuddy` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:

Windows PowerShell:
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Windows CMD:
```cmd
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

5. Install dependencies:
```bash
pip install -r requirements.txt
```

## 2. Configure Gemini

Copy `.env.example` to `.env`.

```text
GEMINI_API_KEY=your_key_here
AI_ENABLED=true
GEMINI_PLAN_MODEL=gemini-3.8-flash
GEMINI_TIP_MODEL=gemini-3.8-flash
ADMIN_TOKEN=change-this-token
```

Get a Gemini API key from Google AI Studio. Keep the key in `.env` and never commit it.

If you leave the key empty or set `AI_ENABLED=false`, FitBuddy runs in demo mode with a deterministic local plan. This is useful for testing the frontend/database without spending API quota.

## 3. Run the application

```bash
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000 — web application
- http://127.0.0.1:8000/docs — Swagger/OpenAPI documentation
- http://127.0.0.1:8000/view-all-users?token=YOUR_ADMIN_TOKEN — admin dashboard

## 4. Test the application

Run:
```bash
pytest -q
```

The tests force demo mode so they do not need a Gemini API key.

## 5. API examples

### Generate a plan

```bash
curl -X POST http://127.0.0.1:8000/api/generate-workout \
  -H "Content-Type: application/json" \
  -d '{
    "user_id":"FB001",
    "name":"Alex",
    "age":21,
    "weight":60,
    "goal":"muscle gain",
    "intensity":"medium"
  }'
```

### Submit feedback

```bash
curl -X POST http://127.0.0.1:8000/api/submit-feedback \
  -H "Content-Type: application/json" \
  -d '{
    "user_id":"FB001",
    "feedback":"Add more cardio and include one additional recovery day."
  }'
```

### Admin users API

```bash
curl http://127.0.0.1:8000/api/users -H "X-Admin-Token: YOUR_ADMIN_TOKEN"
```

## Notes about the supplied documentation

The supplied document specifies Gemini 1.5 Pro and Gemini Flash and the older `google-generativeai` package. This implementation keeps the requested Pro/Flash role split conceptually, but uses Google's current `google-genai` SDK and current model configuration variables so the project can be maintained as Gemini models evolve.

The application uses structured JSON responses rather than raw `<pre>` text. That makes the seven-day plan predictable and lets the Jinja2 UI render each day as a card.

## Safety

FitBuddy is a general wellness/fitness planning demo. It should not be treated as medical advice. The AI prompts explicitly avoid diagnosis, medication, extreme dieting, and dangerous exercise instructions. Users should adapt activity to their ability and consult a qualified healthcare or fitness professional when appropriate.
